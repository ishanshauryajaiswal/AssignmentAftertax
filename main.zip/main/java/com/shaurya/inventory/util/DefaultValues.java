package com.shaurya.inventory.util;

/**
 * Created by ishan.jaiswal on 5/23/2018.
 */

public class DefaultValues {

    private static final String STOCK_IN = "STOCK_IN";
    private static final String STOCK_OUT = "STOCK_OUT";
    private static final String PACKAGING_MATERIAL = "PACKAGING_MATERIAL";
    public static String stringEncodedLogoImage(){
        return "iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAQAAABpN6lAAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAAmJLR0QA/4ePzL8AAAAHdElNRQfhCAoAEhu8kHAdAAAF/klEQVR42u2dW2xUVRSGv2ktUGgrlHJruam0CEGohHuEqhgoIkE0BKWJ8EAwMQGiEaMELzFi9EGUGB4EFJCkatQICS0JYIiExpJIaymVO7RAlYswU1oKpXSOD0WttXPOnjP7zJx1pv96ajpnz/n/fV9r7T3QiU7ENXxi3rQfjzKFXAaxnVf0FXuPAOqpLGQB00i8+3dGPLXQwXxEAOM/9m28kO/FB9xsR97AYGt80C/gagfkDQzW6/wad44BvdnIvJD/Pef1uh/JqRB132rPept+HnWm9A3u8zL9SVy3oH/B240/YEHf4HMvT3snLekbzPDuonynAv1akrwqwFIF+gave5V+puXgZ2AQIN2rAmxVqv/XvEo/lxYF+qfp5lUBvlKgH+QJ7255mxUEWOfd+X+1Av1SunpXgN8UZv+B3qX/gCV9P2O8vP5fYkG/jone3v5uNKV/kbFed38cMKF/nGF4HrUh6ReSShygoUPyl1hEnOD/i+CbfExP4gZ17db7q6Ib+Ym9W7ySAQQ5z2mq2MVxk08mkQK0cF2vH0YnspnAcDLIoA8J+LlEJRWU0xDB+41gCpPJYQiZd6ODt6imhhrKKOUILW5oxukspThkJKeJfbzB6DDLTGE+X3PNYplUzy6WxDJc6mMu22lScmdU8RY5StQL2NFhVDCU3WEXM2IR6n+KsjBes9UOsZIhIcrrxjy+oTHsMlvtV56LpgjjKLX5ogZBSljGgDaldWEmmxWiAlb2E6OiMQgmsZpVEc8gBpXs5yQ9mMTjpGiqmDus4V2CTtb9CBsNP7pW7KT3eKrlyOwGO8VQZ+g/bXuIirbVcL9++i8oua/dYtVk6aWfxy1B9BVdqYnK9EeyW9tIHS0MpC87zT+SoFhUGkX0ErjV9isztMAmYY2/dWs9TZeSMwmKo7+FZF30UzknjHyQN3XuCt4TRr+ZAp0DSRY3hNW+ZnfqOmH1v1Iv/V7Ui6K/UfdM+qoo+mf0L9UOC6LfQp5u+mOFzfw2kGCx+ZW07H1fvwCzBAlQyAndgZHeXNa1lYgCxvOL7hYwSRD9ag7Ze9CMoqTUlO8x9AuQK0iAYrsPmgmQI0iAcvuxvdDOska6CKF/nsH6W0BfMfSh0v6joQXoJ6gD/OGEAJKOKDc4IYAkF3i9EwJ0ESTALScEkJSe3sMJAZoFCZDihAANggTo44QANwQJkB3vAuTYD4N4owuk2t+3hBbgKpLwmH4BLovqBNP1C2BwVpAAs+0m2Jv5A04LEiCZ+foFOCNqFHjJ3kxgJsApUQLk2otimAlQhiy8Yyd510yAcppECTCal3UX+bOw3IAb4S+KzUMfpcI6QXe+C3dr7C0BYDRf6EyPyhSYHmfwaTgSmKfK1jOHTHGtYAJp7NYjAPS3v82IISYzlGI9B+oeFtgFWm1vJH6itjgrVoJL5EfeBSCH8chEDxYyiFIaIyvmEbEtoNWusYp7IxHAxwnhEhgEQuc6WCfB2Ew/cxVaOGZfANjqjhPaEaAwdPBMRYBa9ggXYLPdvcDfWC+afoWZZ0NNgCKOeLP+1Y/NNYpKm22LBhabhc9VUyELxV5ovQG/jhYQJFHkhbbNLNR16Up3LghcAm2KfC/wr5YB5gqr/9ssIKCvuATXX5zQ3j7RrWi+KPp++upvVEWCBFjuRK/Kwi+E/hG1W8gTwxSgnuvMFjD8BXmGGmeK9rFXQP2vdVLdYa4/TXqS7s42sMUuPz0+2fk+ts3FAkTlNwhSlX4OIxa2J1pn3ca48l6B3+kfvanmedfRv83U6M62a10mwLJoLzcS2eEi+p/FYsWVTIlrrtCL0Q25GZS7gP6BWJ5x6hnzZKr99m8h92laFXwZttf4KCUcpYqL1OOnJ2lkMYpR5IV9CnQbL3Iz1rsvH28r5hM1U8Qi08Sb4azgoPLEtwzXIJ/jllfqLlf20jzIGssrvPa67YR7Eiu40uGrHuPDcC+8BRKYzgbOd3iV8o88qafp6kZX5jCLcQwkjT+p5TAH2Wfvfo9/8BATGUM26SRzjmoq+IErdKITnYgcfwHuLbrXGHjyiwAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAxNy0wOC0xMFQwMDoxODoyNyswMDowMMR8EY4AAAAldEVYdGRhdGU6bW9kaWZ5ADIwMTctMDgtMTBUMDA6MTg6MjcrMDA6MDC1IakyAAAAAElFTkSuQmCC";
    }

    public static String getStockMode(int n){
        String stockMode="";
        switch (n){
            case 1:
                stockMode = STOCK_IN;
                break;
            case 2:
                stockMode = STOCK_OUT;
                break;
            case 3:
                stockMode = PACKAGING_MATERIAL;
                break;
        }
        return stockMode;
    }

}
