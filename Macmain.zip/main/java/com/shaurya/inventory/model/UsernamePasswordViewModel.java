package com.shaurya.inventory.model;

import android.databinding.BaseObservable;
import android.databinding.Bindable;

import com.shaurya.inventory.BR;

/**
 * Created by shaurya on 02/05/18.
 */

public class UsernamePasswordViewModel extends BaseObservable {
    String username;
    String password;

    @Bindable
    public String getUsername(){
        return username;
    }

    public void setUsername(String username){
        this.username = username;
        notifyPropertyChanged(BR.username);
    }

    @Bindable
    public String getPassword(){
        return username;
    }

    public void setPassword(String password){
        this.password = password;
        notifyPropertyChanged(BR.password);
    }
}
