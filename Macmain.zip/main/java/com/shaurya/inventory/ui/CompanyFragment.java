package com.shaurya.inventory.ui;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.shaurya.inventory.databinding.FragmentCompanyBinding;
import com.shaurya.inventory.interfaces.FragmentClickListener;
import com.shaurya.inventory.R;

/**
 * Created by shaurya on 07/04/18.
 */

public class CompanyFragment extends Fragment {
    private FragmentClickListener mListener;
    private FragmentCompanyBinding mBinding;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mBinding = FragmentCompanyBinding.inflate(inflater);
        return mBinding.getRoot();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mBinding.tvCompany1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                companySelected(1);
            }
        });
        mBinding.tvCompany2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                companySelected(2);
            }
        });
        mBinding.tvCompany3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                companySelected(3);
            }
        });
    }


    public static CompanyFragment getInstance(){
        return new CompanyFragment();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (getActivity() instanceof FragmentClickListener)
            mListener = (FragmentClickListener) getActivity();
        else
            throw new ClassCastException(getActivity().toString() + " must implement FragmentClickListener");
    }

    public void companySelected(int id){
        switch (id){
            case 1:
                mListener.onCompanySelected(1);
                break;
            case 2:
                mListener.onCompanySelected(2);
                break;
            case 3:
                mListener.onCompanySelected(3);
                break;
        }
    }
}

