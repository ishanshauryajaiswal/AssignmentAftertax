package com.shaurya.inventory.ui;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;

import com.shaurya.inventory.databinding.FragmentProductBinding;
import com.shaurya.inventory.interfaces.FragmentClickListener;
import com.shaurya.inventory.model.Product;
import com.shaurya.inventory.model.Variant;
import com.shaurya.inventory.R;
import com.shaurya.inventory.db.DBHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by shaurya on 07/04/18.
 */

public class ProductFragment extends android.support.v4.app.Fragment {

    List<Product> mProductList = new ArrayList<>();
    List<Variant> mVariantList = new ArrayList<>();
    private FragmentClickListener mListener;
    int companyID, productID, variantQuantity;
    DBHelper mDBHelper;
    private FragmentProductBinding mBinding;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mDBHelper = DBHelper.getInstance(getActivity().getApplication());
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mBinding = FragmentProductBinding.inflate(inflater);
        return mBinding.getRoot();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        companyID = getArguments().getInt(getString(R.string.key_company_id));
        if (mProductList.size()==0) {
            mProductList.addAll(mDBHelper.getProductsBasedOnCompanyID(companyID));
            mBinding.setProductList(mProductList);
            mBinding.setFragmentClickListener(mListener);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (getActivity() instanceof FragmentClickListener)
            mListener = (FragmentClickListener) getActivity();
        else
            throw new ClassCastException(getActivity().toString() + " must implement FragmentClickListener");
    }

    public static ProductFragment getInstance(Context c,int companyID){
        ProductFragment productFragment = new ProductFragment();
        Bundle args = new Bundle();
        args.putInt(c.getString(R.string.key_company_id),companyID);
        productFragment.setArguments(args);
        return productFragment;
    }

    public void showPopup(int productID) {
        this.productID = productID;
        List<String> listForListView = new ArrayList<>();
        mVariantList = mDBHelper.getVariantsBasedOnProductID(productID);
        for (int i=0; i<mVariantList.size(); i++)
            listForListView.add(String.valueOf(mVariantList.get(i).getQuantity()));
        ArrayAdapter<String> mArrayAdapter = new ArrayAdapter<String>(getContext(),android.R.layout.simple_list_item_1,listForListView);
        LayoutInflater layoutInflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View popupView = layoutInflater.inflate(R.layout.popup_layout_product, null);
        ListView lvVariant = popupView.findViewById(R.id.lvProductVariant);
        final PopupWindow popupWindow = new PopupWindow(popupView, 500, 500);
        lvVariant.setAdapter(mArrayAdapter);
        popupWindow.setFocusable(true);
        popupWindow.setBackgroundDrawable(new ColorDrawable());
        popupWindow.showAtLocation(popupView, Gravity.CENTER, 0,0);
        lvVariant.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                popupWindow.dismiss();
                mListener.onVariantSelected(mVariantList.get(position));
            }
        });
    }

}
