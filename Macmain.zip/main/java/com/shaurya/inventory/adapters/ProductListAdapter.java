package com.shaurya.inventory.adapters;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.shaurya.inventory.R;
import com.shaurya.inventory.databinding.CellProductRecyclerViewBinding;
import com.shaurya.inventory.interfaces.FragmentClickListener;
import com.shaurya.inventory.model.Product;

import java.util.List;

/**
 * Created by shaurya on 07/04/18.
 */

public class ProductListAdapter extends RecyclerView.Adapter<ProductListAdapter.BindedViewHolder> {

    private Context mContext;
    private List<Product> mList;
    private FragmentClickListener mListener;
    public ProductListAdapter(Context mContext, List<Product> mList, FragmentClickListener mListener) {
        this.mContext = mContext;
        this.mList = mList;
        this.mListener = mListener;
    }

    @Override
    public BindedViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.cell_product_recycler_view,parent,false);
        return new BindedViewHolder(view);
    }

    @Override
    public void onBindViewHolder(BindedViewHolder holder, int position) {
        final Product product = mList.get(position);
        holder.mBinding.setProduct(product);
        holder.mBinding.setListener(mListener);
        /*holder.mBinding.tvProductName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.onProductSelected(view, product);
            }
        });
        */
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public static class BindedViewHolder extends RecyclerView.ViewHolder{
        CellProductRecyclerViewBinding mBinding;
        public BindedViewHolder(View v){
            super(v);
            mBinding = DataBindingUtil.bind(v);
        }
    }
}
