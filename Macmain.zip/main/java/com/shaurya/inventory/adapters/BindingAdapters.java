package com.shaurya.inventory.adapters;

import android.databinding.BindingAdapter;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.shaurya.inventory.interfaces.FragmentClickListener;
import com.shaurya.inventory.model.Product;

import java.util.List;

/**
 * Created by shaurya on 30/04/18.
 */

public class BindingAdapters {
    @BindingAdapter({"setProductsList","setFragmentClickListener"})
    public static void setProductsList(RecyclerView recyclerView, List<Product> productsList, FragmentClickListener listener){
        if (productsList==null)
            return;
        if (recyclerView.getLayoutManager() == null)
            recyclerView.setLayoutManager(new LinearLayoutManager(recyclerView.getContext()));
        ProductListAdapter adapter = (ProductListAdapter)recyclerView.getAdapter();
        if (adapter == null){
            adapter = new ProductListAdapter(recyclerView.getContext(), productsList, listener);
            recyclerView.setAdapter(adapter);
        }
    }


}
