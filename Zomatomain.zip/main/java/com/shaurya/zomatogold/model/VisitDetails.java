package com.shaurya.zomatogold.model;

import android.databinding.BaseObservable;
import android.databinding.Bindable;
import com.shaurya.zomatogold.BR;

public class VisitDetails extends BaseObservable{
    String restaurantName;
    int visitID;
    String deal;

    @Bindable
    public String getRestaurantName() {
        return restaurantName;
    }

    @Bindable
    public int getVisitID() {
        return visitID;
    }

    @Bindable
    public String getDeal() {
        return deal;
    }

    public void setRestaurantName(String restaurantName) {
        this.restaurantName = restaurantName;
        notifyPropertyChanged(BR.restaurantName);
    }


    public void setVisitID(int visitID) {
        this.visitID = visitID;
        notifyPropertyChanged(BR.visitID);
    }

    public void setDeal(String deal) {
        this.deal = deal;
        notifyPropertyChanged(BR.deal);
    }
}
