package com.shaurya.zomatogold.model;

import android.databinding.BaseObservable;
import android.databinding.Bindable;

import com.shaurya.zomatogold.BR;

public class Dimensions extends BaseObservable {

    int screenWidth, screenHeight;


    @Bindable
    public int getScreenWidth() {
        return screenWidth;
    }

    @Bindable
    public int getScreenHeight() {
        return screenHeight;
    }

    public void setScreenWidth(int screenWidth) {
        this.screenWidth = screenWidth;
        notifyPropertyChanged(BR.screenWidth);
    }

    public void setScreenHeight(int screenHeight) {
        this.screenHeight = screenHeight;
        notifyPropertyChanged(BR.screenHeight);
    }
}
