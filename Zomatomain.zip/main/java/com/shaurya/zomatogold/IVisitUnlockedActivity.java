package com.shaurya.zomatogold;

public interface IVisitUnlockedActivity {

    void onUnlockButtonClicked();

}
