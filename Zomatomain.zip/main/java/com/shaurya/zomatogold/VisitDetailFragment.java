package com.shaurya.zomatogold;

import android.app.Activity;
import android.content.Context;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.shaurya.zomatogold.databinding.FragmentVisitDetailsBinding;
import com.shaurya.zomatogold.model.Dimensions;

public class VisitDetailFragment extends Fragment {

    FragmentVisitDetailsBinding mBinding;
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_visit_details,container,false);
        View view = mBinding.getRoot();
        Dimensions dimensions = new Dimensions();
        dimensions.setScreenHeight(getScreenHeight());
        dimensions.setScreenWidth(getScreenWidth());
        mBinding.setDimensions(dimensions);
        mBinding.setListener((IVisitUnlockedActivity) getActivity());
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    private int getScreenWidth(){
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity)getContext()).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = displayMetrics.widthPixels;
        return width;
    }

    private int getScreenHeight(){
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity)getContext()).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        return height;
    }

    public static VisitDetailFragment newInstance(){
        VisitDetailFragment visitDetailFragment = new VisitDetailFragment();
        return visitDetailFragment;
    }
}
