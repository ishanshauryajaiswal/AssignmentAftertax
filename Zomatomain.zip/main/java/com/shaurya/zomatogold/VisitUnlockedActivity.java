package com.shaurya.zomatogold;

import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class VisitUnlockedActivity extends AppCompatActivity  implements IVisitUnlockedActivity{

    FragmentManager fragmentManager;
    VisitDetailFragment visitDetailFragment;
    VisitUnlockedFragment visitUnlockedFragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visit_unlocked);
        fragmentManager = getSupportFragmentManager();
        visitDetailFragment = VisitDetailFragment.newInstance();
        fragmentManager.beginTransaction()
                .replace(R.id.fragment_container,visitDetailFragment, VisitDetailFragment.class.getSimpleName())
                .addToBackStack(VisitDetailFragment.class.getSimpleName())
                .commit();
    }

    @Override
    public void onUnlockButtonClicked() {
        fragmentManager.beginTransaction()
                .replace(R.id.fragment_container, visitUnlockedFragment, VisitUnlockedFragment.class.getSimpleName())
                .commit();
    }
}
